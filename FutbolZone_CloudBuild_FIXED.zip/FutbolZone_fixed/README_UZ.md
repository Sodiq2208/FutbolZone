# FutbolZone Android loyiha

Bu Android Studio / AndroidIDE orqali APK yig‘ish uchun boshlang‘ich loyiha. Hozirgi sahifa demo ma’lumotlardan foydalanadi; jonli futbol natijalari hali ulanmagan.

## Telefon orqali APK yig‘ish
1. ZIP faylni yuklab olib, arxivdan chiqaring.
2. AndroidIDE kabi Android loyihasini ochib yig‘a oladigan muharrirni ishonchli rasmiy manbadan o‘rnating.
3. Ilovada `FutbolZone` loyiha papkasini oching (ichida `settings.gradle` va `app` papkasi bo‘lishi kerak).
4. Gradle sync/build tugashini kuting; birinchi marta internet kerak bo‘lishi mumkin.
5. Build menyusidan APK yig‘ing. Odatda `app/build/outputs/apk/debug/app-debug.apk` joyida chiqadi.
6. APK’ni o‘zingizning telefoningizga o‘rnatishdan oldin Android so‘ragan bo‘lsa, faqat ishonchli manbadan olingan fayl uchun “Install unknown apps” ruxsatini bering.

Agar build xatosi chiqsa, xato matni yoki skrinshotini yuboring.

Eslatma: ushbu ZIP ichida Gradle wrapper yo‘q. AndroidIDE muhitida Gradle o‘rnatilgan/sozlangan bo‘lishi kerak. APK hali tayyor emas; uni build qilish kerak.
