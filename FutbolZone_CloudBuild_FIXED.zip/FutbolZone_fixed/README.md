# FutbolZone — birinchi prototip

Bu 0.1 versiya telefon brauzerida ishlaydigan, Android WebView ichiga joylashtirishga mo'ljallangan futbol ilovasi interfeysidir.

## Hozir bor
- FutbolZone brendi va qoramtir/yashil dizayn
- Bosh sahifa va namunaviy o'yin kartalari
- Ligalar, statistika va loyiha haqida sahifalari
- Ligalar bo'yicha filtr

## Muhim
- O'yinlar va jadval ma'lumotlari DEMO, jonli yoki rasmiy natijalar emas.
- Jonli hisoblar uchun keyin ma'lumot API'si ulanishi kerak.
- Bu papkada tayyor APK yo'q; Android APK yig'ish uchun Android build muhiti kerak.

## Tez ko'rish
`app/src/main/assets/index.html` faylini brauzerda oching yoki loyiha ichidagi HTML faylini telefoningizga yuboring va Chrome bilan oching.

Keyingi bosqichda bu interfeysni Android Studio/Gradle loyihasiga joylashtirib, APK yig'ish mumkin.
